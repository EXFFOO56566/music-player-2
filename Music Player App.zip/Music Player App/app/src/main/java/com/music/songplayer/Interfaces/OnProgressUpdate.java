package com.music.songplayer.Interfaces;

/**
 * Created by reyansh on 9/12/17.
 */

public interface OnProgressUpdate {
    void onProgressed(int progress);
    void maxProgress(int max);

}
