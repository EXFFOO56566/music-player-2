package com.music.songplayer.Setting;

import android.preference.PreferenceFragment;

/**
 * Created by REYANSH on 8/16/2017.
 */

public class SettingsScrobblingFragment extends PreferenceFragment {
}
