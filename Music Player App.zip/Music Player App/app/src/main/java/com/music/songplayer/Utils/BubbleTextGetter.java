package com.music.songplayer.Utils;

public interface BubbleTextGetter {
    String getTextToShowInBubble(int pos);
}