package com.music.songplayer.Dialogs;

import android.os.Bundle;
import android.support.v4.app.DialogFragment;


public class OpenSettingsDialog extends DialogFragment {

    @Override
    public void onSaveInstanceState(Bundle outState) {
    }
}
