package com.music.songplayer.Interfaces;

/**
 * Created by REYANSH on 19/09/2016.
 */
public interface OnContextItemSelectedListener {
    void OnContextItemSelected(int itemId);
}
