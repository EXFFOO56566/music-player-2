package com.music.songplayer.Models;

/**
 * Created by REYANSH on 8/10/2017.
 */

public class Playlist {
    public long _id;
    public String _name;

    public Playlist(long _id, String _name) {
        this._id = _id;
        this._name = _name;
    }
}
