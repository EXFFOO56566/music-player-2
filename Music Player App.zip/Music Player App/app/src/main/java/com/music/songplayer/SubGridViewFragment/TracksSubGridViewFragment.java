package com.music.songplayer.SubGridViewFragment;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.music.songplayer.Animations.TranslateAnimation;
import com.music.songplayer.AsyncTasks.AsyncAddTo;
import com.music.songplayer.Common;
import com.music.songplayer.Dialogs.PlaylistDialog;
import com.music.songplayer.Interfaces.OnAdapterItemClicked;
import com.music.songplayer.Interfaces.OnScrolledListener;
import com.music.songplayer.Interfaces.OnTaskCompleted;
import com.music.songplayer.LauncherActivity.MainActivity;
import com.music.songplayer.Models.Album;
import com.music.songplayer.Models.Song;
import com.music.songplayer.NowPlaying.NowPlayingActivity;
import com.music.songplayer.R;
import com.music.songplayer.Search.SearchActivity;
import com.music.songplayer.Utils.Constants;
import com.music.songplayer.Utils.CursorHelper;
import com.music.songplayer.Utils.HidingScrollListener;
import com.music.songplayer.Utils.Logger;
import com.music.songplayer.Utils.MusicUtils;
import com.music.songplayer.Utils.TypefaceHelper;

import java.util.ArrayList;

import static com.music.songplayer.Common.LARGE_TABLET_LANDSCAPE;
import static com.music.songplayer.Common.LARGE_TABLET_PORTRAIT;


public class TracksSubGridViewFragment extends Fragment implements MusicUtils.Defs, OnAdapterItemClicked, OnTaskCompleted {

    private boolean mGoingBack = false;

    private ArrayList<Album> mAlbums;
    private SubGridViewAdapter mAdapter;

    private RecyclerView mRecyclerView;
    private Context mContext;

    private TextView mHeaderTextView;
    private TextView mSubHeaderTextView;
    private ImageView mHeaderImage;
    private ImageButton mHeaderPopUp;
    private Common mApp;
    private View mView;

    private RelativeLayout mHeaderLayout;

    private String HEADER_TITLE;
    private int HEADER_SUB_TITLE;


    private String FROM_WHERE;
    private String SELECTION_VALUE;
    private String COVER_PATH;

    private Button mPlayAllButton;
    private Handler mHandler;
//    private View mDummyBackgroundView;

    private OnScrolledListener mOnScrolledListener;
    private ImageButton mSearchButton;
    private ImageButton mBackButton;
    private int mPosition;
    /**
     * Animates the content views in.
     */
    private Runnable animateContent = new Runnable() {

        @Override
        public void run() {

            //Slide down the header image.


            TranslateAnimation slideDown = new TranslateAnimation(mHeaderLayout, 500, null,
                    View.VISIBLE, Animation.RELATIVE_TO_SELF,
                    0.0f, Animation.RELATIVE_TO_SELF, 0.0f,
                    Animation.RELATIVE_TO_SELF, -2.0f,
                    Animation.RELATIVE_TO_SELF, 0.0f);

            slideDown.setAnimationListener(new Animation.AnimationListener() {

                @Override
                public void onAnimationStart(Animation animation) {
                    mHeaderLayout.setVisibility(View.VISIBLE);
                }

                @Override
                public void onAnimationEnd(Animation animation) {

                }

                @Override
                public void onAnimationRepeat(Animation animation) {

                }

            });

            slideDown.animate();
        }

    };
    /**
     * Animates the content views in.
     */
    private Runnable animatebackground = new Runnable() {

        @Override
        public void run() {

            //Slide down the header image.

/*
            TranslateAnimation slideDown = new TranslateAnimation(mDummyBackgroundView, 500, null,
                    View.VISIBLE, Animation.RELATIVE_TO_SELF,
                    0.0f, Animation.RELATIVE_TO_SELF, 0.0f,
                    Animation.RELATIVE_TO_SELF, -2.0f,
                    Animation.RELATIVE_TO_SELF, 0.0f);

            slideDown.setAnimationListener(new Animation.AnimationListener() {

                @Override
                public void onAnimationStart(Animation animation) {
                    mDummyBackgroundView.setVisibility(View.VISIBLE);
                }

                @Override
                public void onAnimationEnd(Animation animation) {

                }

                @Override
                public void onAnimationRepeat(Animation animation) {

                }

            });

            slideDown.animate();*/
        }

    };
    private Runnable initGridView = new Runnable() {

        @Override
        public void run() {
            android.view.animation.TranslateAnimation animation = new
                    android.view.animation.TranslateAnimation(Animation.RELATIVE_TO_SELF, 0.0f,
                    Animation.RELATIVE_TO_SELF, 0.0f,
                    Animation.RELATIVE_TO_SELF, 2.0f,
                    Animation.RELATIVE_TO_SELF, 0.0f);

            animation.setDuration(500);
            animation.setAnimationListener(new Animation.AnimationListener() {

                @Override
                public void onAnimationEnd(Animation arg0) {

                }

                @Override
                public void onAnimationRepeat(Animation arg0) {
                    // TODO Auto-generated method stub

                }

                @Override
                public void onAnimationStart(Animation arg0) {
                    mRecyclerView.setVisibility(View.VISIBLE);


                }

            });

            mRecyclerView.startAnimation(animation);
        }

    };

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.activity_browser_grid_list, container, false);
        mContext = Common.getInstance();
        mApp = (Common) mContext.getApplicationContext();
        Bundle bundle = getArguments();
        mView.setOnClickListener(v -> Logger.log("INTER"));

//        mDummyBackgroundView = mView.findViewById(R.id.background);

        mHeaderLayout = mView.findViewById(R.id.browser_sub_header_layout);
        mHeaderImage = mView.findViewById(R.id.browser_sub_header_image);
        mHeaderTextView = mView.findViewById(R.id.browser_sub_header_text);
        mSubHeaderTextView = mView.findViewById(R.id.browser_sub_header_sub_text);
        mHeaderPopUp = mView.findViewById(R.id.overflow);
        mPlayAllButton = mView.findViewById(R.id.browser_sub_play_all);

        mSearchButton = mView.findViewById(R.id.search_button);
        mBackButton = mView.findViewById(R.id.back_button);

        mHeaderTextView.setTypeface(TypefaceHelper.getTypeface(mContext, TypefaceHelper.FUTURA_BOOK));
        mSubHeaderTextView.setTypeface(TypefaceHelper.getTypeface(mContext, TypefaceHelper.FUTURA_BOOK));
        mPlayAllButton.setTypeface(TypefaceHelper.getTypeface(mContext, TypefaceHelper.FUTURA_BOLD));

        mRecyclerView = mView.findViewById(R.id.browser_sub_grid_view);


        mRecyclerView.setOnTouchListener((v, event) -> {
            MotionEvent e = MotionEvent.obtain(event);
            mHeaderLayout.dispatchTouchEvent(e);
            e.recycle();
            return false;
        });


        HEADER_TITLE = bundle.getString(Constants.HEADER_TITLE);
        HEADER_SUB_TITLE = bundle.getInt(Constants.HEADER_SUB_TITLE);
        FROM_WHERE = bundle.getString(Constants.FROM_WHERE);
        SELECTION_VALUE = "" + bundle.getLong(Constants.SELECTION_VALUE);
        COVER_PATH = bundle.getString(Constants.COVER_PATH);

        mHeaderTextView.setText(HEADER_TITLE);

        int noOfCols;
        if (Common.getOrientation() == Common.ORIENTATION_LANDSCAPE) {
            noOfCols = Common.getNumberOfColms() / 2;
        } else {
            noOfCols = Common.getNumberOfColms();
        }

        mRecyclerView.setLayoutManager(new GridLayoutManager(mContext, noOfCols));

        mHeaderPopUp.setOnClickListener(v -> onPopUpClicked(v));

        mPlayAllButton.setOnClickListener(v -> {
            ArrayList<Song> songs = CursorHelper.getTracksForSelection(FROM_WHERE, SELECTION_VALUE);
            if (songs.size() > 0) {
                mApp.getPlayBackStarter().playSongs(CursorHelper.getTracksForSelection(FROM_WHERE, SELECTION_VALUE), 0);
                startActivity(new Intent(getActivity(), NowPlayingActivity.class));
            } else {
                removeFragment();
            }
        });


        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                try {

                    GridLayoutManager linearLayoutManager = (GridLayoutManager) recyclerView.getLayoutManager();
                    View topChild = recyclerView.getChildAt(0);

                    int scrollY = -(topChild.getTop()) + findRealFirstVisibleItemPosition(linearLayoutManager.findFirstVisibleItemPosition()) * topChild.getHeight();

                    int screen = Common.getDeviceScreenConfiguration();
                    float scrollOffset;
                    if (screen == LARGE_TABLET_PORTRAIT || screen == LARGE_TABLET_LANDSCAPE) {
                        scrollOffset = 550f;
                    } else {
                        scrollOffset = 290f;
                    }
                    int adjustedScrollY = (int) ((-scrollY) - mApp.convertDpToPixels(scrollOffset, mContext));

                    RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) mHeaderLayout.getLayoutParams();
                    params.topMargin = (adjustedScrollY / 3);
                    mHeaderLayout.setLayoutParams(params);


                } catch (Exception e) {
                    e.printStackTrace();
                    Logger.log("" + "CREASH");
                }


            }
        });
        mAdapter = new SubGridViewAdapter(this);


        if (HEADER_SUB_TITLE == 1) {
            mSubHeaderTextView.setText(HEADER_SUB_TITLE + " " + "album");
        } else {
            mSubHeaderTextView.setText(HEADER_SUB_TITLE + " " + "albums");
        }

        mRecyclerView.addOnScrollListener(new HidingScrollListener() {
            @Override
            public void onHide() {
                if (mOnScrolledListener != null)
                    mOnScrolledListener.onScrolledUp();
            }

            @Override
            public void onShow() {
                if (mOnScrolledListener != null)
                    mOnScrolledListener.onScrolledDown();
            }

        });

        setHeaderImage();
        mHandler = new Handler();
        mHandler.postDelayed(initGridView, 50);
        mHandler.postDelayed(animateContent, 50);
        mHandler.postDelayed(animatebackground, 50);

        RelativeLayout relativeLayout = (RelativeLayout) mSearchButton.getParent();
        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) relativeLayout.getLayoutParams();

        params.topMargin = Common.getStatusBarHeight(getActivity());
        relativeLayout.setLayoutParams(params);

        mSearchButton.setOnClickListener(v -> startActivity(new Intent(getActivity(), SearchActivity.class)));
        mBackButton.setOnClickListener(v -> removeFragment());

        mRecyclerView.setAdapter(mAdapter);
        return mView;
    }

    @Override
    public void onResume() {
        super.onResume();
        mAlbums = CursorHelper.getAlbumsForSelection(FROM_WHERE, SELECTION_VALUE);
        mAdapter.update(mAlbums);
        if (mAlbums.size() == 0) {
            removeFragment();
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof MainActivity) {
            mOnScrolledListener = (OnScrolledListener) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mOnScrolledListener = null;
    }

    private void setHeaderImage() {
        try {
            Bitmap artwork = ImageLoader.getInstance().loadImageSync(COVER_PATH);
            if (artwork != null)
                mHeaderImage.setImageBitmap(artwork);
            else {
                mHeaderImage.setImageResource(R.drawable.playthumbnail);
                int padding = MusicUtils.getDPFromPixel(120);
                mHeaderImage.setPadding(padding, padding, padding, padding);
            }
        } catch (Exception e) {
        }
    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case MusicUtils.URI_REQUEST_CODE_DELETE:
                if (resultCode == Activity.RESULT_OK) {
                    Uri treeUri = data.getData();
                    Common.getInstance().getContentResolver().takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    try {
                        MusicUtils.deleteFile(TracksSubGridViewFragment.this, CursorHelper.getTracksForSelection(FROM_WHERE, SELECTION_VALUE), this);
                    } catch (IndexOutOfBoundsException e) {
                        e.printStackTrace();
                    }
                }
                break;
        }
    }

    public void onPopUpMenuClickListener(View v, final int position) {
        final PopupMenu menu = new PopupMenu(getActivity(), v);
        mPosition = position;
        SubMenu sub = (menu.getMenu()).addSubMenu(0, ADD_TO_PLAYLIST, 1, R.string.add_to_playlist);
        MusicUtils.makePlaylistMenu(getActivity(), sub, 0);
        ArrayList<Song> songs = CursorHelper.getTracksForSelection("ALBUMS", "" + mAlbums.get(mPosition)._Id);
        if (checkSongsEmpty(songs, mPosition)) return;

        menu.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case R.id.popup_album_play_next:
                    new AsyncAddTo(mAlbums.get(mPosition)._albumName, false, songs).execute();
                    return true;
                case R.id.popup_album_add_to_queue:
                    new AsyncAddTo(mAlbums.get(mPosition)._albumName, true, songs).execute();
                    return true;
                case NEW_PLAYLIST:
                    PlaylistDialog playlistDialog = new PlaylistDialog();
                    Bundle bundle = new Bundle();
                    bundle.putLongArray("PLAYLIST_IDS", MusicUtils.getPlayListIds(songs));
                    playlistDialog.setArguments(bundle);
                    playlistDialog.show(getChildFragmentManager(), "FRAGMENT_TAG");
                    return true;
                case PLAYLIST_SELECTED:
                    MusicUtils.insertIntoPlayList(mContext, item, songs);
                    return true;
                case R.id.popup_album_delete:
                    try {
                        MusicUtils.deleteFile(TracksSubGridViewFragment.this, songs, this);
                    } catch (IndexOutOfBoundsException e) {
                        e.printStackTrace();
                    }
                    return true;
                default:
                    break;
            }
            return false;
        });
        menu.inflate(R.menu.popup_album);
        menu.show();
    }

    @Override
    public void OnPopUpMenuClicked(View view, int position) {
        onPopUpMenuClickListener(view, position);
    }

    @Override
    public void OnShuffledClicked() {

    }

    @Override
    public void onSongDeleted() {
        mAlbums.remove(mPosition);
        mAdapter.update(mAlbums);
        if (mAlbums.size() == 0) {
            removeFragment();
        }
    }

    private void slideAwayHeader() {
        if (mGoingBack) return;
        TranslateAnimation slideDown = new TranslateAnimation(mHeaderLayout, 500, new AccelerateInterpolator(2.0f),
                View.INVISIBLE, Animation.RELATIVE_TO_SELF,
                0.0f, Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, -2.0f);

        slideDown.setAnimationListener(new Animation.AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mHeaderLayout.setVisibility(View.INVISIBLE);

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }

        });

        slideDown.animate();
    }


    private void slideAwayBackground() {
       /* TranslateAnimation slideDown = new TranslateAnimation(mDummyBackgroundView, 500, new AccelerateInterpolator(2.0f),
                View.INVISIBLE, Animation.RELATIVE_TO_SELF,
                0.0f, Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, -2.0f);

        slideDown.setAnimationListener(new Animation.AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mDummyBackgroundView.setVisibility(View.INVISIBLE);

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }

        });

        slideDown.animate();*/
    }


    private void slideAwayGridView() {
        if (mGoingBack) return;
        android.view.animation.TranslateAnimation animation = new
                android.view.animation.TranslateAnimation(Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, 2.0f);

        animation.setDuration(500);
        animation.setInterpolator(new AccelerateInterpolator(2.0f));
        animation.setAnimationListener(new Animation.AnimationListener() {

            @Override
            public void onAnimationEnd(Animation arg0) {
                mRecyclerView.setVisibility(View.INVISIBLE);
                mGoingBack = false;
                getActivity().getSupportFragmentManager().beginTransaction().remove(TracksSubGridViewFragment.this).commit();
                getActivity().getSupportFragmentManager().popBackStack();
            }

            @Override
            public void onAnimationRepeat(Animation arg0) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onAnimationStart(Animation arg0) {
                mGoingBack = true;
            }

        });
        mRecyclerView.startAnimation(animation);
    }

    public void removeFragment() {
        slideAwayHeader();
        slideAwayBackground();
        slideAwayGridView();
    }


    private void onPopUpClicked(View view) {
        final PopupMenu menu = new PopupMenu(getActivity(), view);
        SubMenu sub = (menu.getMenu()).addSubMenu(0, ADD_TO_PLAYLIST, 1, R.string.add_to_playlist);
        MusicUtils.makePlaylistMenu(getActivity(), sub, 0);
        ArrayList<Song> songs = CursorHelper.getTracksForSelection(FROM_WHERE, SELECTION_VALUE);
        if (songs.size() == 0) {
            removeFragment();
            return;
        }

        menu.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case R.id.menu_play_next:
                    if (mAlbums.size() != 0) {
                        new AsyncAddTo(HEADER_TITLE, false, songs).execute();
                    }
                    break;
                case R.id.menu_shuffle:
                    if (mAlbums.size() != 0) {
                        mApp.getPlayBackStarter().shuffleUp(songs);
                    }
                    break;
                case R.id.menu_add_to_queue:
                    if (mAlbums.size() != 0)
                        new AsyncAddTo(HEADER_TITLE, true, songs).execute();
                    break;
                case R.id.action_search:
                    Intent intent = new Intent(Intent.ACTION_SEARCH);
                    intent.putExtra(SearchManager.QUERY, HEADER_TITLE);
                    startActivity(intent);
                    break;
                case NEW_PLAYLIST:
                    PlaylistDialog playlistDialog = new PlaylistDialog();
                    Bundle bundle = new Bundle();
                    bundle.putLongArray("PLAYLIST_IDS", MusicUtils.getPlayListIds(songs));
                    playlistDialog.setArguments(bundle);
                    playlistDialog.show(getChildFragmentManager(), "FRAGMENT_TAG");
                    break;
                case PLAYLIST_SELECTED:
                    MusicUtils.insertIntoPlayList(mContext, item, songs);
                    break;
                case R.id.menu_delete:
                    try {
                        MusicUtils.deleteFile(this, songs, this);
                    } catch (IndexOutOfBoundsException e) {
                        e.printStackTrace();
                    }
                    break;

            }
            return false;
        });

        menu.inflate(R.menu.popup_sub_list_menu);
        menu.getMenu().findItem(R.id.menu_edit_tags).setVisible(false);
        menu.show();
    }

    public int findRealFirstVisibleItemPosition(int pos) {
        View view;
        final GridLayoutManager linearLayoutManager = (GridLayoutManager) mRecyclerView.getLayoutManager();
        while (pos > 0) {
            view = linearLayoutManager.findViewByPosition(pos - 1);
            if (view == null) {
                break;
            }
            pos = pos - 1;
        }
        return pos / 2;
    }


    public boolean checkSongsEmpty(ArrayList<Song> songs, int pos) {
        if (songs.size() == 0) {
            mAlbums.remove(pos);
            mAdapter.updateData(mAlbums);
            Toast.makeText(mContext, R.string.no_songs_in_this_album, Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }


}